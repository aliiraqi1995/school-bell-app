package com.schoolbell.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.schoolbell.app.ui.MainScreen
import com.schoolbell.app.ui.ScheduleViewModel
import com.schoolbell.app.ui.theme.SchoolBellTheme

class MainActivity : ComponentActivity() {

    private val viewModel: ScheduleViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SchoolBellTheme {
                MainScreen(viewModel = viewModel)
            }
        }
    }
}
