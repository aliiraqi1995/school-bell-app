package com.schoolbell.app.data

import java.util.Locale

/**
 * Represents a lesson or break item in the school schedule.
 */
data class LessonItem(
    val id: String,
    val name: String,
    val durationMinutes: Int,
    val isBreak: Boolean = false
)

/**
 * Configuration settings for the schedule.
 */
data class ScheduleSettings(
    val startHour: Int = 8,
    val startMinute: Int = 15,
    val isScheduleEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val lessons: List<LessonItem> = defaultLessons()
) {
    companion object {
        fun defaultLessons(): List<LessonItem> {
            return listOf(
                LessonItem("1", "الدرس الأول", 35),
                LessonItem("2", "الدرس الثاني", 35),
                LessonItem("3", "الدرس الثالث", 35),
                LessonItem("break_1", "استراحة (فسحة)", 15, isBreak = true),
                LessonItem("4", "الدرس الرابع", 35),
                LessonItem("5", "الدرس الخامس", 35)
            )
        }
    }
}

/**
 * Computed time slot for a lesson or break with calculated start and end times.
 */
data class ScheduledSlot(
    val item: LessonItem,
    val index: Int,
    val startHour: Int,
    val startMinute: Int,
    val endHour: Int,
    val endMinute: Int
) {
    val formattedStartTime: String
        get() = formatTime(startHour, startMinute)

    val formattedEndTime: String
        get() = formatTime(endHour, endMinute)

    private fun formatTime(hour: Int, minute: Int): String {
        val amPm = if (hour >= 12) "م" else "ص"
        val displayHour = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        return String.format(Locale.getDefault(), "%02d:%02d %s", displayHour, minute, amPm)
    }
}
