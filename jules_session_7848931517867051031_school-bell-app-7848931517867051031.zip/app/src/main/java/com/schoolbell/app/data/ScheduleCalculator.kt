package com.schoolbell.app.data

/**
 * Utility to calculate sequential lesson schedule times.
 */
object ScheduleCalculator {

    /**
     * Calculates start and end times for all lessons sequentially based on start time.
     */
    fun calculateSchedule(settings: ScheduleSettings): List<ScheduledSlot> {
        val result = mutableListOf<ScheduledSlot>()
        var currentMinutes = settings.startHour * 60 + settings.startMinute

        settings.lessons.forEachIndexed { index, lesson ->
            val startTotal = currentMinutes
            val endTotal = startTotal + lesson.durationMinutes

            val startH = (startTotal / 60) % 24
            val startM = startTotal % 60
            val endH = (endTotal / 60) % 24
            val endM = endTotal % 60

            result.add(
                ScheduledSlot(
                    item = lesson,
                    index = index,
                    startHour = startH,
                    startMinute = startM,
                    endHour = endH,
                    endMinute = endM
                )
            )

            currentMinutes = endTotal
        }

        return result
    }
}
