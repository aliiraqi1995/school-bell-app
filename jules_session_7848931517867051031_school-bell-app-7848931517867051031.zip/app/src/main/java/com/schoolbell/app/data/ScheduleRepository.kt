package com.schoolbell.app.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson

class ScheduleRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getSettings(): ScheduleSettings {
        val json = prefs.getString(KEY_SETTINGS, null) ?: return ScheduleSettings()
        return try {
            gson.fromJson(json, ScheduleSettings::class.java) ?: ScheduleSettings()
        } catch (e: Exception) {
            ScheduleSettings()
        }
    }

    fun saveSettings(settings: ScheduleSettings) {
        val json = gson.toJson(settings)
        prefs.edit().putString(KEY_SETTINGS, json).apply()
    }

    companion object {
        private const val PREFS_NAME = "school_bell_prefs"
        private const val KEY_SETTINGS = "schedule_settings"
    }
}
