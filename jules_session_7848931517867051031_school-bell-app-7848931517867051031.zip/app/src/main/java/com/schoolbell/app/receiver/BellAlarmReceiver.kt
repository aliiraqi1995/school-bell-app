package com.schoolbell.app.receiver

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Vibrator
import android.os.VibrationEffect
import androidx.core.app.NotificationCompat
import com.schoolbell.app.MainActivity
import com.schoolbell.app.R
import com.schoolbell.app.data.ScheduleCalculator
import com.schoolbell.app.data.ScheduleRepository
import java.util.Calendar

class BellAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            scheduleAlarms(context)
            return
        }

        val lessonName = intent.getStringExtra(EXTRA_LESSON_NAME) ?: "درس"
        val isStart = intent.getBooleanVariable(EXTRA_IS_START, true)
        val eventMessage = if (isStart) "بداية $lessonName" else "نهاية $lessonName"

        playBellSoundAndVibrate(context)
        showNotification(context, lessonName, eventMessage)

        // Reschedule alarms for future days if schedule is enabled
        scheduleAlarms(context)
    }

    private fun Intent.getBooleanVariable(key: String, defaultValue: Boolean): Boolean {
        return getBooleanExtra(key, defaultValue)
    }

    private fun playBellSoundAndVibrate(context: Context) {
        try {
            // Play alarm ringtone
            val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val ringtone: Ringtone = RingtoneManager.getRingtone(context, alarmUri)
            ringtone.play()

            // Stop ringtone after 5 seconds
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                if (ringtone.isPlaying) {
                    ringtone.stop()
                }
            }, 5000)

            // Vibrate
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(1000)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showNotification(context: Context, title: String, message: String) {
        val channelId = "school_bell_channel"
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "School Bell Notifications",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيهات جرس المدرسة"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val activityIntent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("جرس المدرسة: $title")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }

    companion object {
        const val EXTRA_LESSON_NAME = "extra_lesson_name"
        const val EXTRA_IS_START = "extra_is_start"
        const val ACTION_RING_BELL = "com.schoolbell.app.ACTION_RING_BELL"

        fun scheduleAlarms(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val repository = ScheduleRepository(context)
            val settings = repository.getSettings()

            if (!settings.isScheduleEnabled) {
                cancelAllAlarms(context)
                return
            }

            val slots = ScheduleCalculator.calculateSchedule(settings)
            val now = Calendar.getInstance()

            slots.forEachIndexed { index, slot ->
                // Schedule start time
                val startCal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, slot.startHour)
                    set(Calendar.MINUTE, slot.startMinute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }

                if (startCal.before(now)) {
                    startCal.add(Calendar.DAY_OF_YEAR, 1)
                }

                val startIntent = Intent(context, BellAlarmReceiver::class.java).apply {
                    action = ACTION_RING_BELL
                    putExtra(EXTRA_LESSON_NAME, slot.item.name)
                    putExtra(EXTRA_IS_START, true)
                }
                val startPendingIntent = PendingIntent.getBroadcast(
                    context,
                    index * 2,
                    startIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        startCal.timeInMillis,
                        startPendingIntent
                    )
                } else {
                    alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        startCal.timeInMillis,
                        startPendingIntent
                    )
                }

                // Schedule end time
                val endCal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, slot.endHour)
                    set(Calendar.MINUTE, slot.endMinute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }

                if (endCal.before(now)) {
                    endCal.add(Calendar.DAY_OF_YEAR, 1)
                }

                val endIntent = Intent(context, BellAlarmReceiver::class.java).apply {
                    action = ACTION_RING_BELL
                    putExtra(EXTRA_LESSON_NAME, slot.item.name)
                    putExtra(EXTRA_IS_START, false)
                }
                val endPendingIntent = PendingIntent.getBroadcast(
                    context,
                    index * 2 + 1,
                    endIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        endCal.timeInMillis,
                        endPendingIntent
                    )
                } else {
                    alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        endCal.timeInMillis,
                        endPendingIntent
                    )
                }
            }
        }

        fun cancelAllAlarms(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            for (i in 0..20) {
                val intent = Intent(context, BellAlarmReceiver::class.java).apply {
                    action = ACTION_RING_BELL
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    i,
                    intent,
                    PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
                )
                if (pendingIntent != null) {
                    alarmManager.cancel(pendingIntent)
                    pendingIntent.cancel()
                }
            }
        }
    }
}
