package com.schoolbell.app.ui

import android.app.Application
import android.content.Context
import android.media.Ringtone
import android.media.RingtoneManager
import androidx.lifecycle.AndroidViewModel
import com.schoolbell.app.data.LessonItem
import com.schoolbell.app.data.ScheduleCalculator
import com.schoolbell.app.data.ScheduleRepository
import com.schoolbell.app.data.ScheduleSettings
import com.schoolbell.app.data.ScheduledSlot
import com.schoolbell.app.receiver.BellAlarmReceiver
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class ScheduleViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ScheduleRepository(application)

    private val _settings = MutableStateFlow(repository.getSettings())
    val settings: StateFlow<ScheduleSettings> = _settings.asStateFlow()

    private val _scheduledSlots = MutableStateFlow<List<ScheduledSlot>>(emptyList())
    val scheduledSlots: StateFlow<List<ScheduledSlot>> = _scheduledSlots.asStateFlow()

    private var previewRingtone: Ringtone? = null

    init {
        updateSlots()
    }

    private fun updateSlots() {
        val calculated = ScheduleCalculator.calculateSchedule(_settings.value)
        _scheduledSlots.value = calculated
    }

    private fun saveAndSchedule(newSettings: ScheduleSettings) {
        _settings.value = newSettings
        repository.saveSettings(newSettings)
        updateSlots()
        BellAlarmReceiver.scheduleAlarms(getApplication())
    }

    fun toggleSchedule(enabled: Boolean) {
        saveAndSchedule(_settings.value.copy(isScheduleEnabled = enabled))
    }

    fun updateStartTime(hour: Int, minute: Int) {
        saveAndSchedule(_settings.value.copy(startHour = hour, startMinute = minute))
    }

    fun updateLessonDuration(lessonId: String, newDuration: Int) {
        val updatedLessons = _settings.value.lessons.map { lesson ->
            if (lesson.id == lessonId) {
                lesson.copy(durationMinutes = newDuration)
            } else lesson
        }
        saveAndSchedule(_settings.value.copy(lessons = updatedLessons))
    }

    fun updateLessonName(lessonId: String, newName: String) {
        val updatedLessons = _settings.value.lessons.map { lesson ->
            if (lesson.id == lessonId) {
                lesson.copy(name = newName)
            } else lesson
        }
        saveAndSchedule(_settings.value.copy(lessons = updatedLessons))
    }

    fun addLesson(name: String, duration: Int, isBreak: Boolean) {
        val newLesson = LessonItem(
            id = UUID.randomUUID().toString(),
            name = name,
            durationMinutes = duration,
            isBreak = isBreak
        )
        val updatedLessons = _settings.value.lessons + newLesson
        saveAndSchedule(_settings.value.copy(lessons = updatedLessons))
    }

    fun removeLesson(lessonId: String) {
        val updatedLessons = _settings.value.lessons.filterNot { it.id == lessonId }
        saveAndSchedule(_settings.value.copy(lessons = updatedLessons))
    }

    fun resetToDefaults() {
        saveAndSchedule(ScheduleSettings())
    }

    fun testBellSound() {
        try {
            val context: Context = getApplication()
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            previewRingtone?.stop()
            previewRingtone = RingtoneManager.getRingtone(context, uri)
            previewRingtone?.play()

            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                previewRingtone?.stop()
            }, 3000)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
