package com.schoolbell.app

import com.schoolbell.app.data.LessonItem
import com.schoolbell.app.data.ScheduleCalculator
import com.schoolbell.app.data.ScheduleSettings
import org.junit.Assert.assertEquals
import org.junit.Test

class ScheduleCalculatorTest {

    @Test
    fun testScheduleCalculationWithDefaultSettings() {
        val settings = ScheduleSettings(
            startHour = 8,
            startMinute = 15,
            lessons = listOf(
                LessonItem("1", "الدرس الأول", 35),
                LessonItem("2", "الدرس الثاني", 35),
                LessonItem("3", "الدرس الثالث", 35),
                LessonItem("break", "استراحة", 15, isBreak = true),
                LessonItem("4", "الدرس الرابع", 35),
                LessonItem("5", "الدرس الخامس", 35)
            )
        )

        val slots = ScheduleCalculator.calculateSchedule(settings)

        assertEquals(6, slots.size)

        // Lesson 1: 08:15 -> 08:50
        assertEquals(8, slots[0].startHour)
        assertEquals(15, slots[0].startMinute)
        assertEquals(8, slots[0].endHour)
        assertEquals(50, slots[0].endMinute)

        // Lesson 2: 08:50 -> 09:25
        assertEquals(8, slots[1].startHour)
        assertEquals(50, slots[1].startMinute)
        assertEquals(9, slots[1].endHour)
        assertEquals(25, slots[1].endMinute)

        // Lesson 3: 09:25 -> 10:00
        assertEquals(9, slots[2].startHour)
        assertEquals(25, slots[2].startMinute)
        assertEquals(10, slots[2].endHour)
        assertEquals(0, slots[2].endMinute)

        // Break: 10:00 -> 10:15
        assertEquals(10, slots[3].startHour)
        assertEquals(0, slots[3].startMinute)
        assertEquals(10, slots[3].endHour)
        assertEquals(15, slots[3].endMinute)

        // Lesson 4: 10:15 -> 10:50
        assertEquals(10, slots[4].startHour)
        assertEquals(15, slots[4].startMinute)
        assertEquals(10, slots[4].endHour)
        assertEquals(50, slots[4].endMinute)

        // Lesson 5: 10:50 -> 11:25
        assertEquals(10, slots[5].startHour)
        assertEquals(50, slots[5].startMinute)
        assertEquals(11, slots[5].endHour)
        assertEquals(25, slots[5].endMinute)
    }

    @Test
    fun testScheduleCalculationWithCustomStartAndDurations() {
        val settings = ScheduleSettings(
            startHour = 9,
            startMinute = 0,
            lessons = listOf(
                LessonItem("1", "الدرس الأول", 40),
                LessonItem("2", "الدرس الثاني", 40)
            )
        )

        val slots = ScheduleCalculator.calculateSchedule(settings)

        assertEquals(2, slots.size)

        // Lesson 1: 09:00 -> 09:40
        assertEquals(9, slots[0].startHour)
        assertEquals(0, slots[0].startMinute)
        assertEquals(9, slots[0].endHour)
        assertEquals(40, slots[0].endMinute)

        // Lesson 2: 09:40 -> 10:20
        assertEquals(9, slots[1].startHour)
        assertEquals(40, slots[1].startMinute)
        assertEquals(10, slots[1].endHour)
        assertEquals(20, slots[1].endMinute)
    }
}
